- Date: 10/05/2015

Python Script to find Web Site Admin Login Page.
